import { getReservations } from "@/services/reservation.service";

export default async function AdminDashboard() {
  try {
    const reservations = await getReservations();

    // Calcular estadísticas
    const totalReserved = reservations.length;
    const pendingReservations = reservations.filter(
      (r) => r.status === "pending"
    ).length;

    // Calcular ingresos totales de reservas aprobadas
    const priceMap = {
      oficina: 290000,
      coworking: 350000,
      "sala-juntas": 420000,
      auditorio: 550000,
    };

    const totalIncome = reservations
      .filter((r) => r.status === "approved")
      .reduce((sum, reservation) => {
        const price =
          priceMap[reservation.spaceType] || 0;
        return sum + price;
      }, 0);

    // Calcular espacios totales disponibles
    const totalSpaces = {
      oficina: 20,
      coworking: 15,
      "sala-juntas": 10,
      auditorio: 5,
    };

    const reservedSpacesByType = {};
    const totalReservedSpaces = {};

    Object.keys(totalSpaces).forEach((type) => {
      reservedSpacesByType[type] = reservations.filter(
        (r) =>
          r.spaceType === type &&
          r.status === "approved"
      ).length;
      totalReservedSpaces[type] = totalSpaces[type];
    });

    const totalAvailableSpaces = Object.keys(
      totalSpaces
    ).reduce((sum, type) => {
      return (
        sum +
        (totalSpaces[type] -
          (reservedSpacesByType[type] || 0))
      );
    }, 0);

    // Mapeo de nombres para mostrar
    const typeNames = {
      oficina: "Oficinas",
      coworking: "Coworking",
      "sala-juntas": "Salas de Juntas",
      auditorio: "Auditorios",
    };

    // Colores por tipo de espacio
    const typeColors = {
      oficina:
        "bg-blue-100 text-blue-800 border-blue-300",
      coworking:
        "bg-green-100 text-green-800 border-green-300",
      "sala-juntas":
        "bg-purple-100 text-purple-800 border-purple-300",
      auditorio:
        "bg-orange-100 text-orange-800 border-orange-300",
    };

    return `
      <section class="grid gap-4 mb-6 md:grid-cols-2 lg:grid-cols-4">
        
        <!-- Card: Salas Reservadas -->
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow-lg">
          <div class="flex justify-between items-start">
            <div>
              <p class="text-blue-100 text-sm font-medium">
                Salas Reservadas
              </p>
              <h3 class="text-4xl font-bold mt-2">
                ${totalReserved}
              </h3>
            </div>
            <div class="text-4xl opacity-20">
              📅
            </div>
          </div>
          <p class="text-blue-100 text-xs mt-3">
            Total de reservas en el sistema
          </p>
        </div>

        <!-- Card: Dinero que Entró -->
        <div class="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-lg shadow-lg">
          <div class="flex justify-between items-start">
            <div>
              <p class="text-green-100 text-sm font-medium">
                Ingresos Totales
              </p>
              <h3 class="text-4xl font-bold mt-2">
                $${(totalIncome / 1000).toFixed(0)}K
              </h3>
            </div>
            <div class="text-4xl opacity-20">
              💰
            </div>
          </div>
          <p class="text-green-100 text-xs mt-3">
            De reservas aprobadas
          </p>
        </div>

        <!-- Card: Solicitudes Pendientes -->
        <div class="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white p-6 rounded-lg shadow-lg">
          <div class="flex justify-between items-start">
            <div>
              <p class="text-yellow-100 text-sm font-medium">
                Pendientes
              </p>
              <h3 class="text-4xl font-bold mt-2">
                ${pendingReservations}
              </h3>
            </div>
            <div class="text-4xl opacity-20">
              ⏳
            </div>
          </div>
          <p class="text-yellow-100 text-xs mt-3">
            Esperando aprobación
          </p>
        </div>

        <!-- Card: Salas Disponibles -->
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 rounded-lg shadow-lg">
          <div class="flex justify-between items-start">
            <div>
              <p class="text-purple-100 text-sm font-medium">
                Disponibles
              </p>
              <h3 class="text-4xl font-bold mt-2">
                ${totalAvailableSpaces}
              </h3>
            </div>
            <div class="text-4xl opacity-20">
              ✅
            </div>
          </div>
          <p class="text-purple-100 text-xs mt-3">
            Listas para reservar
          </p>
        </div>

      </section>

      <!-- Detalles por tipo de espacio -->
      <section class="bg-white p-6 rounded-lg shadow mb-6">
        <h2 class="font-bold text-xl mb-4">
          Disponibilidad por Tipo
        </h2>
        
        <div class="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          ${Object.keys(totalSpaces)
            .map((type) => {
              const reserved =
                reservedSpacesByType[type] || 0;
              const total = totalSpaces[type];
              const available = total - reserved;
              const percentage = Math.round(
                (reserved / total) * 100
              );

              return `
                <div class="border-2 border-slate-200 p-4 rounded-lg">
                  <h3 class="font-semibold text-sm mb-2">
                    ${typeNames[type]}
                  </h3>
                  
                  <div class="space-y-2">
                    <div class="flex justify-between text-xs">
                      <span class="text-slate-600">
                        Reservadas
                      </span>
                      <span class="font-bold">
                        ${reserved}/${total}
                      </span>
                    </div>
                    
                    <div class="w-full bg-slate-200 rounded-full h-2">
                      <div
                        class="bg-blue-500 h-2 rounded-full transition-all"
                        style="width: ${percentage}%"
                      ></div>
                    </div>
                    
                    <div class="flex justify-between text-xs">
                      <span class="text-green-600 font-semibold">
                        ${available} disponibles
                      </span>
                      <span class="text-slate-500">
                        ${percentage}% ocupado
                      </span>
                    </div>
                  </div>
                </div>
              `;
            })
            .join("")}
        </div>
      </section>

      <!-- Resumen de ingresos -->
      <section class="bg-white p-6 rounded-lg shadow">
        <h2 class="font-bold text-xl mb-4">
          Resumen de Ingresos
        </h2>
        
        <div class="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          ${Object.keys(typeNames)
            .map((type) => {
              const reserved =
                reservedSpacesByType[type] || 0;
              const pricePerDay = priceMap[type] || 0;
              const income = reserved * pricePerDay;

              return `
                <div class="border-2 ${typeColors[type]} p-4 rounded-lg">
                  <h3 class="font-semibold text-sm mb-2">
                    ${typeNames[type]}
                  </h3>
                  
                  <div class="space-y-1 text-sm">
                    <div class="flex justify-between">
                      <span>Reservadas:</span>
                      <span class="font-bold">
                        ${reserved}
                      </span>
                    </div>
                    
                    <div class="flex justify-between">
                      <span>Precio/día:</span>
                      <span class="font-bold">
                        $${(pricePerDay / 1000).toFixed(0)}K
                      </span>
                    </div>
                    
                    <div class="border-t pt-1 mt-1 flex justify-between font-bold">
                      <span>Ingresos:</span>
                      <span>
                        $${(income / 1000).toFixed(0)}K
                      </span>
                    </div>
                  </div>
                </div>
              `;
            })
            .join("")}
        </div>
      </section>
    `;
  } catch (error) {
    console.error(error);
    return `
      <div class="bg-red-100 border border-red-300 text-red-800 p-4 rounded mb-6">
        Error al cargar el dashboard: ${error.message}
      </div>
    `;
  }
}
