import { removeSession } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar() {
  setTimeout(() => {
    document
      .querySelector("#logoutBtn")
      ?.addEventListener("click", () => {
        removeSession();
        navigateTo("/");
      });

    document
      .querySelector("#newReservationBtn")
      ?.addEventListener("click", () => {
        showNewReservationModal();
      });
  });

  return `
    <aside
      class="w-64 bg-slate-900 text-white h-screen p-5 fixed"
    >
      <h2 class="text-2xl font-bold mb-8">
        SPA Reservas
      </h2>

      <nav class="flex flex-col gap-4">

        <a href="/home" class="px-3 py-1 bg-gray-500 rounded-xl hover:bg-gray-600 transition" data-link>
          Home
        </a>

        <button
          id="newReservationBtn"
          class="text-left cursor-pointer text-green-400 hover:text-white hover:bg-green-600 px-3 py-1 rounded-xl transition"
        >
          Nueva Reserva
        </button>

        <button
          id="logoutBtn"
          class="text-left cursor-pointer text-red-400 hover:text-white hover:bg-red-600 px-3 py-1 rounded-xl transition"
        >
          Cerrar sesión
        </button>

      </nav>

    </aside>
  `;
}

const showNewReservationModal = () => {
  const { getSession } = require("@/utils");
  const { createReservation } = require("@services/reservation.service");
  const { homeController } = require("@controllers/home.controller");

  const user = getSession();
  const today = new Date().toISOString().split("T")[0];

  const modal = document.createElement("div");
  modal.className =
    "fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50";
  modal.innerHTML = `
    <div class="bg-white p-8 rounded-lg shadow w-96">
      <h2 class="text-xl font-bold mb-4">
        Nueva Reserva
      </h2>
      <form id="newReservationForm">
        <input
          type="text"
          name="workspace"
          placeholder="Workspace"
          class="border w-full p-2 rounded mb-3"
          required
        >
        <input
          type="date"
          name="date"
          value="${today}"
          min="${today}"
          class="border w-full p-2 rounded mb-3"
          required
        >
        <input
          type="time"
          name="startHour"
          class="border w-full p-2 rounded mb-3"
          required
        >
        <input
          type="time"
          name="endHour"
          class="border w-full p-2 rounded mb-3"
          required
        >
        <textarea
          name="reason"
          placeholder="Motivo de la reserva"
          class="border w-full p-2 rounded mb-3"
          required
        ></textarea>
        <div class="flex gap-2">
          <button
            type="submit"
            class="flex-1 bg-green-600 text-white py-2 rounded hover:bg-green-700"
          >
            Crear
          </button>
          <button
            type="button"
            class="flex-1 bg-gray-400 text-white py-2 rounded hover:bg-gray-500"
            onclick="this.closest('.fixed').remove()"
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  `;

  document.body.appendChild(modal);

  modal
    .querySelector("#newReservationForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData);

      try {
        const reservation = {
          ...data,
          userId: user.id,
          status: "pending",
        };

        await createReservation(reservation);
        modal.remove();
        const { homeController } = require("@controllers/home.controller");
        await homeController();
      } catch (error) {
        alert("Error al crear la reserva");
        console.error(error);
      }
    });
};