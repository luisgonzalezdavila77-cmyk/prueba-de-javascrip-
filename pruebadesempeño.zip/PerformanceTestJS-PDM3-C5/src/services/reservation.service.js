import { http } from "@/api/http";

export const getReservations = () =>
  http.get("/reservations");

export const getReservationById = (id) =>
  http.get(`/reservations/${id}`);

export const createReservation = (data) =>
  http.post("/reservations", data);

export const updateReservation = (id, data) =>
  http.put(`/reservations/${id}`, data);

export const deleteReservation = (id) =>
  http.delete(`/reservations/${id}`);

export const getUsers = () =>
  http.get("/users");

export const getUserById = (id) =>
  http.get(`/users/${id}`);

export const createUser = (data) =>
  http.post("/users", data);

export const updateUser = (id, data) =>
  http.put(`/users/${id}`, data);

export const deleteUser = (id) =>
  http.delete(`/users/${id}`);