/**
 * ROUTER SPA - Sistema de enrutamiento sin librerías externas
 * 
 * Implementa:
 * ✓ Navegación sin recargas de página
 * ✓ Renderizado dinámico con JavaScript
 * ✓ History API para manejo de URLs
 * ✓ Protección de rutas
 * ✓ Manejo de rutas inexistentes (404)
 */

import loginView from "@/views/loginView";
import registerView from "@/views/registerView";
import homeView from "@/views/homeView";
import notFoundView from "@/views/notFound";
import { isAuthenticated, isAdmin } from "@/utils";

/**
 * ROUTE CONFIGURATION
 */

// Public routes (accessible without authentication)
const publicRoutes = ["/", "/login", "/register"];

// Route map: path → view function
// Each function returns an HTML string that is rendered dynamically
const routes = {
  "/": loginView,         // Root route → login
  "/login": loginView,    // Explicit route → login
  "/register": registerView, // Registration route
  "/home": homeView,      // Protected route → dashboard
  "/404": notFoundView,   // Not found route
};

/**
 * FUNCIÓN: navigateTo(path)
 * 
 * Cambia la URL sin recargar la página usando History API
 * 
 * @param {string} path - Ruta destino (ej: "/home", "/login")
 * 
 * Flujo:
 * 1. history.pushState() cambia la URL del navegador
 * 2. NO dispara recarga de página
 * 3. router() procesa la nueva URL
 * 4. Vista se renderiza dinámicamente
 * 
 * Ejemplo:
 * navigateTo("/home")
 * → URL: / → /home
 * → Sin recarga
 * → Renderiza homeView
 */
export const navigateTo = (path) => {
  // ✓ Cambiar URL con History API (sin recargar)
  // Sintaxis: pushState(state, title, url)
  history.pushState({}, "", path);
  
  // ✓ Renderizar la nueva vista
  router();
};

/**
 * FUNCIÓN: router()
 * 
 * Renderiza dinámicamente la vista correcta según la URL actual
 * Implementa navegación sin recargas de página
 * Soporta vistas async
 * 
 * Flujo:
 * 1. Lee la URL actual (window.location.pathname)
 * 2. Valida autenticación si es ruta protegida
 * 3. Selecciona la vista correcta
 * 4. Genera HTML dinámicamente (view())
 * 5. Inserta en el DOM (#app)
 * 
 * Ejemplo:
 * URL: http://localhost:5173/home
 * → router() → homeView() → HTML → Inserta en #app
 */
export const router = async () => {
  // ✓ Obtener contenedor principal
  const app = document.querySelector("#app");
  
  // ✓ Leer URL actual del navegador
  let path = window.location.pathname;

  /**
   * VALIDACIÓN: ¿Ruta protegida sin autenticación?
   * 
   * Si:
   * - La ruta NO está en publicRoutes (privada)
   * - Y el usuario NO está autenticado
   * 
   * Entonces:
   * - Redirigir a "/" (login)
   */
  if (!publicRoutes.includes(path) && !isAuthenticated()) {
    path = "/";
  }

  /**
   * VALIDACIÓN: ¿Ruta existe?
   * 
   * Si la ruta no está mapeada:
   * - Mostrar página 404
   */
  const view = routes[path];
  if (!view) {
    path = "/404";
  }

  /**
   * RENDERIZADO DINÁMICO
   * 
   * 1. routes[path]() ejecuta la función view
   * 2. La función retorna un string HTML (async o sync)
   * 3. app.innerHTML actualiza el DOM
   * 4. ✓ SIN RECARGA DE PÁGINA
   * 
   * Ejemplo:
   * routes["/home"]() → homeView() → retorna `<div>...</div>` → insertado en #app
   */
  const htmlContent = await routes[path]();
  app.innerHTML = htmlContent;

  /**
   * NOTA: El controller se ejecuta en las vistas
   * Cada vista usa setTimeout para permitir que el DOM esté listo
   * 
   * Ejemplo en homeView.js:
   * setTimeout(() => {
   *   homeController();  // Agrega event listeners
   * });
   */
};

/**
 * EVENT LISTENER: Cambios en el histórico del navegador
 * 
 * Se dispara cuando:
 * - Usuario hace clic en botón ATRÁS del navegador
 * - Usuario hace clic en botón ADELANTE
 * - Se llama history.back() o history.forward()
 * 
 * Flujo:
 * 1. Navegador cambia URL internamente
 * 2. Evento "popstate" se dispara
 * 3. router() re-renderiza la vista
 * 4. Usuario ve página anterior/siguiente
 * 
 * Ejemplo:
 * Usuario en /home → botón ATRÁS → URL → / → router() → loginView
 */
window.addEventListener("popstate", router);
