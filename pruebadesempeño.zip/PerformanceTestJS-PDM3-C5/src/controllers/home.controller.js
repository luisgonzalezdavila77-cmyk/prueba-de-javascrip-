import ReservationCard from "@components/ReservationCard";
import {
  getReservations,
  createReservation,
  updateReservation,
  deleteReservation,
} from "@services/reservation.service";
import { getSession, isAdmin } from "@/utils";
import { http } from "@/api/http";

// Precios por tipo
const prices = {
  oficina: "290.000",
  coworking: "350.000",
  "sala-juntas": "420.000",
  auditorio: "550.000",
  otro: "Consultar",
};

// Número de espacios por tipo
const spaceCount = {
  oficina: 20,
  coworking: 15,
  "sala-juntas": 10,
  auditorio: 5,
  otro: 0,
};

// Mapeo de nombres
const spaceNames = {
  oficina: "Oficina",
  coworking: "Coworking",
  "sala-juntas": "Sala de Juntas",
  auditorio: "Auditorio",
};

export const homeController = async () => {
  const container = document.querySelector(
    "#reservationsContainer",
  );
  const user = getSession();

  try {
    const reservations = await getReservations();

    const filteredReservations =
      user.role === "admin"
        ? reservations
        : reservations.filter(
            (reservation) =>
              reservation.userId === user.id,
          );

    container.innerHTML = filteredReservations?.length
      ? filteredReservations
          .map((reservation) =>
            ReservationCard(reservation),
          )
          .join("")
      : `
      <div class="w-full text-center py-8 col-span-2">
        <p class="text-slate-500">
          No hay reservas disponibles
        </p>
      </div>
    `;

    // Agregar event listeners a los botones
    setupEventListeners(
      filteredReservations,
      user,
    );
    
    // Agregar listener al botón de nueva reserva
    setupNewReservationButton();
  } catch (error) {
    console.error(error);
    container.innerHTML = `
      <div class="w-full text-center py-8 col-span-2">
        <p class="text-red-500">
          Error al cargar las reservas
        </p>
      </div>
    `;
  }
};

const setupNewReservationButton = () => {
  const newReservationBtn = document.getElementById(
    "newReservationBtn",
  );
  
  if (newReservationBtn) {
    // Remover listeners anteriores para evitar duplicados
    const newBtn = newReservationBtn.cloneNode(true);
    newReservationBtn.parentNode.replaceChild(newBtn, newReservationBtn);
    
    // Agregar nuevo listener
    const freshBtn = document.getElementById("newReservationBtn");
    if (freshBtn) {
      freshBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        showCreateModal();
      });
    }
  }
};

const setupEventListeners = (
  reservations,
  user,
) => {
  // Botones de eliminar
  document
    .querySelectorAll("[data-delete-btn]")
    .forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const reservationId = btn.dataset.deleteBtn;
        const reservation = reservations.find(
          (r) => r.id == reservationId,
        );

        if (
          !isAdmin() &&
          reservation.userId !== user.id
        ) {
          alert(
            "No tienes permiso para eliminar esta reserva",
          );
          return;
        }

        if (
          confirm(
            "¿Estás seguro de que deseas eliminar esta reserva?",
          )
        ) {
          try {
            await deleteReservation(reservationId);
            await homeController();
          } catch (error) {
            alert(
              "Error al eliminar la reserva",
            );
          }
        }
      });
    });

  // Botones de editar
  document
    .querySelectorAll("[data-edit-btn]")
    .forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const reservationId = btn.dataset.editBtn;
        const reservation = reservations.find(
          (r) => r.id == reservationId,
        );

        if (
          !isAdmin() &&
          reservation.userId !== user.id
        ) {
          alert(
            "No tienes permiso para editar esta reserva",
          );
          return;
        }

        showEditModal(reservation);
      });
    });

  // Botones de aprobar (solo admin)
  document
    .querySelectorAll("[data-approve-btn]")
    .forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const reservationId = btn.dataset.approveBtn;

        try {
          // Usar PATCH para solo actualizar el status, sin perder otros campos
          await http.patch(`/reservations/${reservationId}`, {
            status: "approved",
          });
          await homeController();
        } catch (error) {
          console.error(error);
          alert(
            "Error al aprobar la reserva",
          );
        }
      });
    });

  // Botones de rechazar (solo admin)
  document
    .querySelectorAll("[data-reject-btn]")
    .forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const reservationId = btn.dataset.rejectBtn;

        try {
          // Usar PATCH para solo actualizar el status, sin perder otros campos
          await http.patch(`/reservations/${reservationId}`, {
            status: "rejected",
          });
          await homeController();
        } catch (error) {
          console.error(error);
          alert(
            "Error al rechazar la reserva",
          );
        }
      });
    });
};

const updateWorkspaceOptions = (selectedType, workspaceSelect, workspaceInput) => {
  workspaceSelect.innerHTML = '<option value="">Selecciona espacio</option>';
  
  if (selectedType && spaceCount[selectedType] > 0) {
    const count = spaceCount[selectedType];
    const name = spaceNames[selectedType];
    for (let i = 1; i <= count; i++) {
      const option = document.createElement("option");
      option.value = `${name} ${i}`;
      option.textContent = `${name} ${i}`;
      workspaceSelect.appendChild(option);
    }
    workspaceSelect.classList.remove("hidden");
    workspaceInput.classList.add("hidden");
    workspaceInput.removeAttribute("required");
    workspaceSelect.setAttribute("required", "required");
  } else if (selectedType) {
    workspaceSelect.classList.add("hidden");
    workspaceInput.classList.remove("hidden");
    workspaceInput.setAttribute("required", "required");
    workspaceSelect.removeAttribute("required");
  }
};

const showEditModal = (reservation) => {
  const modal = document.createElement("div");
  modal.className =
    "fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50";
  modal.innerHTML = `
    <div class="bg-white p-8 rounded-lg shadow w-96 max-h-screen overflow-y-auto">
      <h2 class="text-xl font-bold mb-4">
        Editar Reserva
      </h2>
      <form id="editForm">
        <label class="block text-sm font-medium mb-1">
          Tipo de Espacio
        </label>
        <select
          id="spaceTypeSelect"
          name="spaceType"
          class="border w-full p-2 rounded mb-3"
          required
        >
          <option value="">Selecciona un tipo</option>
          <option value="oficina" ${reservation.spaceType === "oficina" ? "selected" : ""}>Oficina Privada - $290.000/día</option>
          <option value="coworking" ${reservation.spaceType === "coworking" ? "selected" : ""}>Coworking - $350.000/día</option>
          <option value="sala-juntas" ${reservation.spaceType === "sala-juntas" ? "selected" : ""}>Sala de Juntas - $420.000/día</option>
          <option value="auditorio" ${reservation.spaceType === "auditorio" ? "selected" : ""}>Auditorio - $550.000/día</option>
          <option value="otro" ${reservation.spaceType === "otro" ? "selected" : ""}>Otro - Consultar precio</option>
        </select>

        <div id="priceDisplay" class="bg-blue-50 border border-blue-200 p-3 rounded mb-3">
          <p class="text-sm font-medium text-blue-900">
            Precio: <span id="priceValue" class="font-bold text-lg text-blue-600">$290.000/día</span>
          </p>
        </div>

        <label class="block text-sm font-medium mb-1">
          Nombre del espacio
        </label>
        <select
          id="workspaceSelect"
          name="workspace"
          class="border w-full p-2 rounded mb-3 hidden"
          required
        >
          <option value="">Selecciona espacio</option>
        </select>
        <input
          type="text"
          id="workspaceInput"
          name="workspace"
          placeholder="O escribe manualmente"
          value="${reservation.workspace}"
          class="border w-full p-2 rounded mb-3"
        >

        <label class="block text-sm font-medium mb-1">
          Fecha
        </label>
        <input
          type="date"
          name="date"
          value="${reservation.date}"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <label class="block text-sm font-medium mb-1">
          Hora de inicio
        </label>
        <input
          type="time"
          name="startHour"
          value="${reservation.startHour}"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <label class="block text-sm font-medium mb-1">
          Hora de finalizacion
        </label>
        <input
          type="time"
          name="endHour"
          value="${reservation.endHour}"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <label class="block text-sm font-medium mb-1">
          Motivo
        </label>
        <textarea
          name="reason"
          placeholder="Motivo"
          class="border w-full p-2 rounded mb-3"
          required
        >${reservation.reason}</textarea>

        <div class="flex gap-2">
          <button
            type="submit"
            class="flex-1 bg-blue-600 text-white py-2 rounded"
          >
            Guardar
          </button>
          <button
            type="button"
            class="flex-1 bg-gray-400 text-white py-2 rounded"
            onclick="this.closest('.fixed').remove()"
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  `;

  document.body.appendChild(modal);

  const spaceTypeSelect = modal.querySelector("#spaceTypeSelect");
  const workspaceSelect = modal.querySelector("#workspaceSelect");
  const workspaceInput = modal.querySelector("#workspaceInput");
  const priceValue = modal.querySelector("#priceValue");

  spaceTypeSelect.addEventListener("change", (e) => {
    const selectedType = e.target.value;
    if (selectedType) {
      const price = prices[selectedType];
      if (price === "Consultar") {
        priceValue.textContent = "Precio a consultar";
      } else {
        priceValue.textContent = `${price}/día`;
      }
      updateWorkspaceOptions(selectedType, workspaceSelect, workspaceInput);
    }
  });

  workspaceSelect.addEventListener("change", (e) => {
    if (e.target.value) {
      workspaceInput.value = e.target.value;
    }
  });

  // Mostrar precio inicial y opciones de espacios
  if (reservation.spaceType) {
    const initialPrice = prices[reservation.spaceType];
    if (initialPrice === "Consultar") {
      priceValue.textContent = "Precio a consultar";
    } else {
      priceValue.textContent = `${initialPrice}/día`;
    }
    updateWorkspaceOptions(reservation.spaceType, workspaceSelect, workspaceInput);
    
    // Pre-seleccionar el espacio actual
    if (workspaceSelect.querySelector(`option[value="${reservation.workspace}"]`)) {
      workspaceSelect.value = reservation.workspace;
    }
  }

  modal
    .querySelector("#editForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData);

      // Si se seleccionó del dropdown, usar ese valor
      if (workspaceSelect.value) {
        data.workspace = workspaceSelect.value;
      }

      // Agregar precio
      data.price = prices[data.spaceType];

      try {
        await updateReservation(
          reservation.id,
          data,
        );
        modal.remove();
        await homeController();
      } catch (error) {
        alert(
          "Error al actualizar la reserva",
        );
      }
    });
};


const showCreateModal = () => {
  const user = getSession();
  const modal = document.createElement("div");
  modal.className =
    "fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50";
  modal.innerHTML = `
    <div class="bg-white p-8 rounded-lg shadow w-96 max-h-screen overflow-y-auto">
      <h2 class="text-xl font-bold mb-4">
        Nueva Reserva
      </h2>
      <form id="createForm">
        <label class="block text-sm font-medium mb-1">
          Tipo de Espacio
        </label>
        <select
          id="spaceTypeSelect"
          name="spaceType"
          class="border w-full p-2 rounded mb-3"
          required
        >
          <option value="">Selecciona un tipo</option>
          <option value="oficina">Oficina Privada - $290.000/día</option>
          <option value="coworking">Coworking - $350.000/día</option>
          <option value="sala-juntas">Sala de Juntas - $420.000/día</option>
          <option value="auditorio">Auditorio - $550.000/día</option>
          <option value="otro">Otro - Consultar precio</option>
        </select>

        <div id="priceDisplay" class="bg-blue-50 border border-blue-200 p-3 rounded mb-3 hidden">
          <p class="text-sm font-medium text-blue-900">
            Precio: <span id="priceValue" class="font-bold text-lg text-blue-600">$290.000/día</span>
          </p>
        </div>

        <label class="block text-sm font-medium mb-1">
          Nombre del espacio
        </label>
        <select
          id="workspaceSelect"
          name="workspace"
          class="border w-full p-2 rounded mb-3 hidden"
          required
        >
          <option value="">Selecciona espacio</option>
        </select>
        <input
          type="text"
          id="workspaceInput"
          name="workspace"
          placeholder="ej: Oficina 101, Sala A, Coworking Norte"
          class="border w-full p-2 rounded mb-3"
        >

        <label class="block text-sm font-medium mb-1">
          Fecha
        </label>
        <input
          type="date"
          name="date"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <label class="block text-sm font-medium mb-1">
          Hora de inicio
        </label>
        <input
          type="time"
          name="startHour"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <label class="block text-sm font-medium mb-1">
          Hora de finalización
        </label>
        <input
          type="time"
          name="endHour"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <label class="block text-sm font-medium mb-1">
          Motivo de la reserva
        </label>
        <textarea
          name="reason"
          placeholder="Describe el motivo de tu reserva"
          class="border w-full p-2 rounded mb-3"
          required
        ></textarea>

        <div class="flex gap-2">
          <button
            type="submit"
            class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2 rounded font-medium transition"
          >
            Crear Reserva
          </button>
          <button
            type="button"
            class="flex-1 bg-gray-400 hover:bg-gray-500 text-white py-2 rounded font-medium transition"
            onclick="this.closest('.fixed').remove()"
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  `;

  document.body.appendChild(modal);

  const spaceTypeSelect = modal.querySelector("#spaceTypeSelect");
  const workspaceSelect = modal.querySelector("#workspaceSelect");
  const workspaceInput = modal.querySelector("#workspaceInput");
  const priceDisplay = modal.querySelector("#priceDisplay");
  const priceValue = modal.querySelector("#priceValue");

  spaceTypeSelect.addEventListener("change", (e) => {
    const selectedType = e.target.value;
    if (selectedType) {
      const price = prices[selectedType];
      if (price === "Consultar") {
        priceValue.textContent = "Precio a consultar";
      } else {
        priceValue.textContent = `${price}/día`;
      }
      priceDisplay.classList.remove("hidden");
      updateWorkspaceOptions(selectedType, workspaceSelect, workspaceInput);
    } else {
      priceDisplay.classList.add("hidden");
    }
  });

  workspaceSelect.addEventListener("change", (e) => {
    if (e.target.value) {
      workspaceInput.value = e.target.value;
    }
  });

  modal
    .querySelector("#createForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData);

      // Si se seleccionó del dropdown, usar ese valor
      if (workspaceSelect.value) {
        data.workspace = workspaceSelect.value;
      }

      // Agregar userId y status por defecto
      data.userId = user.id;
      data.status = "pending";

      // Agregar precio
      data.price = prices[data.spaceType];

      // Validación: hora de finalización debe ser mayor que la de inicio
      if (data.endHour <= data.startHour) {
        alert(
          "La hora de finalización debe ser mayor que la de inicio",
        );
        return;
      }

      // Validación: tipo de espacio seleccionado
      if (!data.spaceType) {
        alert(
          "Debes seleccionar un tipo de espacio",
        );
        return;
      }

      // Validación: nombre del espacio
      if (!data.workspace) {
        alert(
          "Debes seleccionar o escribir el nombre del espacio",
        );
        return;
      }

      try {
        await createReservation(data);
        modal.remove();
        await homeController();
        alert("¡Reserva creada exitosamente!");
      } catch (error) {
        console.error(error);
        alert(
          "Error al crear la reserva. Por favor intenta de nuevo.",
        );
      }
    });
};
