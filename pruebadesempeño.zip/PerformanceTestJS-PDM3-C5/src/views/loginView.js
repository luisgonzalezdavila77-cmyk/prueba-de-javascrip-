import { loginController } from "@/controllers/login.controller";
import { isAuthenticated } from "@/utils";
import { navigateTo } from "@/router/router";

export default function loginView() {
  // If user is already authenticated, redirect to home
  if (isAuthenticated()) {
    setTimeout(() => {
      navigateTo("/home");
    });
  }

  setTimeout(() => {
    loginController();
  });

  return `
    <div class="min-h-screen flex justify-center items-center bg-gradient-to-br from-blue-600 to-blue-800">

      <div class="bg-white p-8 rounded-lg shadow-2xl w-full max-w-md">

        <div class="text-center mb-8">
          <h1 class="text-3xl font-bold text-blue-600">
            LGC Reserva de Oficinas
          </h1>
          <p class="text-slate-500 mt-2">
            Workspace Management System
          </p>
        </div>

        <form id="loginForm" class="space-y-4">

          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">
              Email
            </label>
            <input
              type="email"
              name="email"
              placeholder="admin@test.com"
              class="border w-full p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 transition"
              required
            >
          </div>

          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">
              Password
            </label>
            <input
              type="password"
              name="password"
              placeholder="A123456"
              class="border w-full p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 transition"
              required
            >
          </div>

          <button
            type="submit"
            class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            Sign In
          </button>

        </form>

        <div class="mt-6 text-center">
          <p class="text-sm text-slate-600">
            Don't have an account?
            <a
              href="#"
              onclick="event.preventDefault(); navigateTo('/register')"
              class="text-blue-600 hover:text-blue-700 font-medium"
            >
              Create one
            </a>
          </p>
        </div>

        <div class="mt-8 pt-6 border-t">
          <p class="text-sm text-slate-600 mb-3">
            <strong>Test Credentials:</strong>
          </p>
          <ul class="text-xs text-slate-500 space-y-1">
            <li>• <strong>Admin:</strong> admin@test.com / A123456</li>
            <li>• <strong>User:</strong> user@test.com / A123456</li>
          </ul>
        </div>

      </div>

    </div>
  `;
}

// Make navigateTo available in onclick
window.navigateTo = navigateTo;