import Sidebar from "@/components/Sidebar";
import AdminDashboard from "@/components/AdminDashboard";
import UserManagement from "@/components/UserManagement";
import { getSession } from "@/utils";
import { homeController } from "@/controllers/home.controller";

export default async function homeView() {
  const user = getSession();

  let dashboardHTML = "";
  let userManagementHTML = "";
  if (user?.role === "admin") {
    dashboardHTML = await AdminDashboard();
    userManagementHTML = await UserManagement();
  }

  setTimeout(() => {
    homeController();
  });

  return `
    <div class="flex">

      ${Sidebar()}

      <main class="flex-1 ml-64 p-6 bg-slate-100 min-h-screen">

        <div class="mb-6">

          <h1 class="text-3xl font-bold mb-2">
            Bienvenido ${user?.name}
          </h1>

          <p class="text-slate-600">
            <strong>Rol:</strong> 
            <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
              ${user?.role === "admin" ? "Administrador" : "Usuario"}
            </span>
          </p>

        </div>

        ${
          user?.role === "admin"
            ? `
              <section
                class="bg-white p-5 rounded-lg shadow mb-6"
              >
                <h2 class="font-bold text-xl mb-2">
                  Admin Panel
                </h2>

                <p class="text-slate-600 mb-3">
                  You have access to all system reservations. You can approve, reject or delete any reservation.
                </p>

              </section>

              ${dashboardHTML}
              
              ${userManagementHTML}
            `
            : `
              <section
                class="bg-white p-5 rounded-lg shadow mb-6"
              >
                <h2 class="font-bold text-xl mb-2">
                  User Panel
                </h2>

                <p class="text-slate-600 mb-3">
                  You can view, create, edit and delete only your own reservations while they are in pending status.
                </p>

              </section>
            `
        }

        <section
          class="bg-white p-6 rounded-lg shadow"
        >

          <div
            class="flex justify-between items-center mb-6"
          >
            <h2 class="font-bold text-2xl">
              Reservas
            </h2>

            <div class="flex gap-2 items-center">
              <span
                class="text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded"
              >
                ${
                  user?.role === "admin"
                    ? "Todas las reservas"
                    : "Mis reservas"
                }
              </span>
              <button
                id="newReservationBtn"
                class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded font-medium transition"
              >
                + Nueva Reserva
              </button>
            </div>
          </div>

          <div
            id="reservationsContainer"
            class="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
          >
            <div class="w-full text-center py-8 col-span-full">
              <p class="text-emerald-800">
                Cargando reservas ...
              </p>
            </div>
          </div>

        </section>

      </main>

    </div>
  `;
}